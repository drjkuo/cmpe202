

public interface State {
 
	//public void insertCoin(int c);
	//public void insertDime();
	//public void insertNickel();
	public void ejectCoin();
	public void turnCrank();
	public void dispense();
	public void insertCoin(int c);
}
