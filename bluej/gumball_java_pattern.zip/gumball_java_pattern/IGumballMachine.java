
public interface IGumballMachine {
	void insertQuarter();
	void insertDime();
	void insertNickel();
	void turnCrank();
	boolean isGumballInSlot(); 
	void takeGumballFromSlot();
}